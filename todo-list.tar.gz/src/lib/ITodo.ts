export default interface ITodo {
    id: string,
    name: string
    done: boolean
}